"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Github, Linkedin, Mail } from "lucide-react"
import { NightWeatherBackground } from "@/components/night-weather-background"
import { ResumeModal } from "@/components/resume-modal"
import { TypingText } from "@/components/typing-text"

export default function Home() {
  const [isResumeOpen, setIsResumeOpen] = useState(false)

  return (
    <>
            <main className="min-h-screen flex items-center justify-center p-6">
      <NightWeatherBackground />
        <div className="max-w-2xl w-full text-center space-y-8">
          {/* Avatar */}

          <TypingText />

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              size="lg"
              variant="outline"
              className="gap-2 bg-transparent text-white border-white hover:bg-white hover:text-black hover:scale-110 hover:shadow-[0_0_20px_rgba(255,255,255,0.8)] transition-all duration-300"
              onClick={() => setIsResumeOpen(true)}
            >
              View Resume
            </Button>
          </div>

          {/* Social Links */}
          <div className="flex items-center justify-center gap-4 pt-6">
            <Button
              variant="ghost"
              size="icon"
              asChild
              className="text-white hover:bg-white hover:text-black hover:scale-125 hover:shadow-[0_0_20px_rgba(255,255,255,0.8)] transition-all duration-300"
            >
              <a href="https://github.com/baris386" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
                <Github className="h-5 w-5" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              asChild
              className="text-white hover:bg-white hover:text-black hover:scale-125 hover:shadow-[0_0_20px_rgba(255,255,255,0.8)] transition-all duration-300"
            >
              <a href="https://www.linkedin.com/in/barış-abbaszadə-498054385/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              asChild
              className="text-white hover:bg-white hover:text-black hover:scale-125 hover:shadow-[0_0_20px_rgba(255,255,255,0.8)] transition-all duration-300"
            >
              <a href="mailto:abbaszadb26@gmail.com" aria-label="Email">
                <Mail className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </main>

      <ResumeModal isOpen={isResumeOpen} onClose={() => setIsResumeOpen(false)} />
    </>
  )
}
